const contactForm =
    document.getElementById("contactForm");

const formMessage =
    document.getElementById("formMessage");


if (contactForm) {

    contactForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const name =
                document.getElementById("name")
                .value.trim();

            const email =
                document.getElementById("email")
                .value.trim();

            const message =
                document.getElementById("message")
                .value.trim();


            if (!name || !email || !message) {

                formMessage.textContent =
                    "Please fill in all fields.";

                return;
            }


            try {

                const response =
                    await fetch("/api/contact", {

                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            name: name,
                            email: email,
                            message: message
                        })
                    });


                const data =
                    await response.json();


                if (response.ok) {

                    formMessage.textContent =
                        "Your message has been sent successfully!";

                    contactForm.reset();

                } else {

                    formMessage.textContent =
                        data.message ||
                        "Something went wrong.";
                }


            } catch (error) {

                formMessage.textContent =
                    "Unable to connect to the server.";

                console.error(error);
            }

        }
    );
}